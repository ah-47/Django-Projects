import json
import urllib.request
from django.shortcuts import render
from datetime import datetime


def index(request):
    if request.method == 'POST':
        city = request.POST['city']
        url = f"http://api.weatherapi.com/v1/current.json?key=f3a461aee8354e4786e131449241101&q={city}"

        try:
            req = urllib.request.urlopen(url).read()
            weather_dict = json.loads(req)  # convert string into dictionaries

            location_time = weather_dict.get('location', {}).get('localtime', '')

            if location_time:
                location_time = datetime.strptime(location_time, "%Y-%m-%d %H:%M")
                location_time = location_time.strftime("%Y-%m-%d %I:%M %p")

            data = {
                'city': city,
                'region': weather_dict['location'].get('region', ''),
                'country': weather_dict['location'].get('country', ''),
                'temperature': weather_dict['current'].get('temp_c', ''),
                'wind_speed': weather_dict['current'].get('wind_kph', ''),
                'wind_degree': weather_dict['current'].get('wind_degree', ''),
                'humidity': weather_dict['current'].get('humidity', ''),
                'uv': weather_dict['current'].get('uv', ''),
                'location_time': location_time,
            }

        except Exception as e:
            print("Error:", e)
            data = {'city': city}

    else:
        city = ''
        data = {}

    return render(request, 'index.html', {'data': data})
